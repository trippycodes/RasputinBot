import subprocess
from discord.ext import tasks


def install_dependencies():
    try:
        # Run the pip command to install dependencies from requirements.txt
        subprocess.check_call(["pip", "install", "-r", "requirements.txt"])
        print("Dependencies installed successfully.")
    except subprocess.CalledProcessError:
        print("Error: Failed to install dependencies.")


# Call the function to install dependencies
install_dependencies()

import discord
from discord.ext import commands, tasks
from discord.ext.commands import CommandNotFound
import asyncio
import os
import random
import wikipediaapi
import wikipedia
from datetime import datetime
import requests
from bs4 import BeautifulSoup

intents = discord.Intents.default()
intents.typing = False
intents.presences = False
intents.members = True  # Required for member joins and leaves
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

MUTED_ROLE_NAME = "Muted"

def log_action(action, member, reason, author):
    log_entry = f"[{datetime.now()}] {action} - Member: {member}, Reason: {reason}, Author: {author}\n"
    with open("log.txt", "a") as log_file:  # Replace "log.txt" with your desired file name
        log_file.write(log_entry)

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name} - {bot.user.id}')

@bot.event
async def on_message(message):
    if message.author.bot:
        return

    # Check for excessive capital letter spam
    if len([c for c in message.content if c.isupper()]) >= 5:
        await message.delete()
        await message.author.send("Please avoid excessive use of capital letters.")
        muted_role = discord.utils.get(message.guild.roles, name=MUTED_ROLE_NAME)
        await message.author.add_roles(muted_role)
        await message.channel.send(
            f'{message.author.mention} has been muted for excessive capital letter spam.'
        )
        await asyncio.sleep(900)  # Mute for 15 minutes
        await message.author.remove_roles(muted_role)

    # Continue with other checks and commands
    await bot.process_commands(message)

@bot.command()
async def ping(ctx):
    await ctx.send('Pong!')

@bot.command()
@commands.has_permissions(manage_roles=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    await member.kick(reason=reason)
    await ctx.send(f'Kicked {member.mention}')

    log_action("Kick", member, reason, ctx.author)

@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, reason="No reason provided."):
    ban_message_channel = bot.get_channel(BAN_MESSAGE_CHANNEL_ID)
    if ban_message_channel:
        await ban_message_channel.send(f"PROTOCOL_AURORA_RETROFLEX=ACTIVE {member.mention} for: {reason}")
    
    await member.ban(reason=reason)
    await ctx.send(f'Banned {member.mention}')
    
    log_action("Ban", member, reason, ctx.author)

BAN_MESSAGE_CHANNEL_ID = 1145995742515839018


@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name} - {bot.user.id}')

@bot.command()
async def info(ctx):
    embed = discord.Embed(title='Bot Information', color=discord.Color.blue())
    embed.add_field(name='Author', value='Your Name', inline=False)
    embed.add_field(name='Description',
                    value='A simple moderating and interactive bot',
                    inline=False)
    embed.add_field(name='Prefix', value='!', inline=False)
    await ctx.send(embed=embed)

@bot.command()
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member, *, reason=None):
    # Implement mute logic
    pass

    log_action("Mute", member, reason, ctx.author)

@bot.command()
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    # Implement unmute logic
    pass

    log_action("Unmute", member, "No reason provided", ctx.author)

@bot.command()
async def rps(ctx, choice: str = None):
    if not choice:
        await ctx.send("Please choose either rock, paper, or scissors.")
        return

    choices = ["rock", "paper", "scissors"]
    user_choice = choice.lower()

    if user_choice not in choices:
        await ctx.send("Please choose either rock, paper, or scissors.")
        return

    bot_choice = random.choice(choices)
    result = determine_winner(user_choice, bot_choice)
    await ctx.send(f"You chose {user_choice}, I chose {bot_choice}. {result}")

def determine_winner(user_choice, bot_choice):
    if user_choice == bot_choice:
        return "It's a tie!"
    elif user_choice == "rock":
        return "You win!" if bot_choice == "scissors" else "I win!"
    elif user_choice == "paper":
        return "You win!" if bot_choice == "rock" else "I win!"
    elif user_choice == "scissors":
        return "You win!" if bot_choice == "paper" else "I win!"

@bot.command()
async def fact(ctx):
    try:
        random_fact = wikipedia.summary(wikipedia.random(), sentences=1)
        await ctx.send(random_fact)
    except wikipedia.exceptions.DisambiguationError:
        await ctx.send("Could not fetch a random fact at the moment. Try again later.")

# Continue with other commands and functionalities

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, CommandNotFound):
        await ctx.send("Command not found. Use !help to see available commands.")
    else:
        await ctx.send(f"An error occurred: {error}")

# Run the bot
bot.run('put your bot token between these')
