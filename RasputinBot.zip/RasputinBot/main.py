import subprocess

def install_dependencies():
    try:
        # Run the pip command to install dependencies from requirements.txt
        subprocess.check_call(["pip", "install", "-r", "requirements.txt"])
        print("Dependencies installed successfully.")
    except subprocess.CalledProcessError:
        print("Error: Failed to install dependencies.")

# Call the function to install dependencies
install_dependencies()


import discord
from discord.ext import commands
from discord.ext.commands import CommandNotFound
import asyncio

intents = discord.Intents.default()
intents.typing = False
intents.presences = False
intents.members = True  # Required for member joins and leaves
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

MUTED_ROLE_NAME = "Muted"

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name} - {bot.user.id}')

@bot.event
async def on_message(message):
    if message.author.bot:
        return
    
    # Check for excessive capital letter spam
    if len([c for c in message.content if c.isupper()]) >= 5:
        await message.delete()
        await message.author.send("Please avoid excessive use of capital letters.")
        muted_role = discord.utils.get(message.guild.roles, name=MUTED_ROLE_NAME)
        await message.author.add_roles(muted_role)
        await message.channel.send(f'{message.author.mention} has been muted for excessive capital letter spam.')
        await asyncio.sleep(900)  # Mute for 15 minutes
        await message.author.remove_roles(muted_role)

    # Continue with other checks and commands
    await bot.process_commands(message)

@bot.command()
async def ping(ctx):
    await ctx.send('Pong!')

@bot.command()
@commands.has_permissions(manage_roles=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    await member.kick(reason=reason)
    await ctx.send(f'Kicked {member.mention}')

@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    await member.ban(reason=reason)
    await ctx.send(f'Banned {member.mention}')

@bot.command()
async def info(ctx):
    embed = discord.Embed(title='Bot Information', color=discord.Color.blue())
    embed.add_field(name='Author', value='Your Name', inline=False)
    embed.add_field(name='Description', value='A simple moderating and interactive bot', inline=False)
    embed.add_field(name='Prefix', value='!', inline=False)
    await ctx.send(embed=embed)

@bot.command()
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member, *, reason=None):
    # Implement mute logic
    pass

@bot.command()
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    # Implement unmute logic
    pass

@bot.command()
async def rps(ctx):
    # Implement rock-paper-scissors game
    pass

# Continue with other commands and functionalities

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, CommandNotFound):
        await ctx.send("Command not found. Use !help to see available commands.")
    else:
        await ctx.send(f"An error occurred: {error}")

bot.run('PASTE YOUR BOT TOKEN HERE BE CAREFUL IF YOU SHARE THIS SCRIPT TO DELETE YOUR TOKEN FIRST')
